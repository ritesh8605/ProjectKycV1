
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";




function CandidateSignUp() {

   

    const history=useHistory();
    const CandidateSignUp2=()=>{
        history.push("/CandidateSignUp2")
    }

   
    return<>

        <div> 
            <div className="jumbotron" style={{backgroundColor:'rgb(250, 248, 228)'}} >
                <center><h1>Candidate Sign Up</h1></center>     
                <center><h2>Enter Details</h2></center>  
                <center><h2>1/3</h2></center>     

            </div>  
        </div>
    

  

    <div className="container-fluid text-center"> 

  <div className="row content">
    <div className="col-lg-5 sidenav">

    <div>
    <div><center><big>First Name</big></center></div>
    <input type="text" placeholder="Enter First Name" className="form-control"></input>
    </div>

    <br></br>
    <div>
    <div><center><big>Last Name</big></center></div>
    <input type="text" placeholder="Enter Last Name" className="form-control"></input>
    </div>

    <br></br>
    <div>
    <div><center><big>DOB</big></center></div>
    <input type="date" className="form-control"></input>
    </div>

    <br></br>
    <div>
    <div><center><big>Age Proof</big></center></div>
    <input type="number" placeholder="Enter A Valid Id number" className="form-control"></input>
    </div>
   

    </div>
    <div className="col-lg-2 text-center"> 

    </div>
    <div className="col-lg-5 sidenav">

    <div>
    <div><center><big>Enter A Valid Email</big></center></div>
    <input type="text" placeholder="Enter Email For UserID" className="form-control"></input>
    </div>
      
    <br></br>
    <div>
    <div><center><big>Password</big></center></div>
    <input type="text" placeholder="Enter the Password" className="form-control"></input>
    </div>

    <br></br>
    <div>
    <div><center><big>Confirm Password</big></center></div>
    <input type="text" placeholder="Confirm Password" className="form-control"></input>
    </div>

    <br></br>
    <div>
    <div><center><big>Contact</big></center></div>
    <input type="text" placeholder="Enter Contact Number" className="form-control"></input>
    </div>

    </div>
  </div>
  <br></br><br></br>
  <div><button type="button" class="btn btn-success" onClick={CandidateSignUp2}>Next</button></div>
</div>


    </>
}

export default CandidateSignUp;