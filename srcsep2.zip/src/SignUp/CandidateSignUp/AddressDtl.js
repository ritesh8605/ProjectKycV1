import { useHistory } from "react-router-dom/cjs/react-router-dom.min";



function AddressDtl() {

    const history = useHistory();
    const CandidateSignUp3 = () => {
        history.push("/CandidateSignUp3");
    }
    return <>

        <div>
            <div className="jumbotron" style={{ backgroundColor: 'rgb(250, 248, 228)' }} >
                <center><h1>Candidate Sign Up</h1></center>
                <center><h2>Enter Details</h2></center>
                <center><h2>2/3</h2></center>
            </div>
        </div>




        <div className="container-fluid text-center">

            <div className="row content">
                <div className="col-lg-5 sidenav">

                    <div>
                        <div><center><big>Conutry</big></center></div>
                        <input type="text" placeholder="Enter First Name" className="form-control"></input>
                    </div>

                    <br></br>
                    <div>
                        <div><center><big>State</big></center></div>
                        <input type="text" placeholder="Enter Last Name" className="form-control"></input>
                    </div>

                    <br></br>
                    <div>
                        <div><center><big>District</big></center></div>
                        <input type="text" placeholder="District" className="form-control"></input>
                    </div>

                    <br></br>
                    <div>
                        <div><center><big>City</big></center></div>
                        <input type="number" placeholder="Enter A Valid Id number" className="form-control"></input>
                    </div>


                </div>
                <div className="col-lg-2 text-center">

                </div>
                <div className="col-lg-5 sidenav">



                    <div>
                        <div><center><big>Pincode</big></center></div>
                        <input type="number" placeholder="Enter the Password" className="form-control"></input>
                    </div>

                    <br></br>Select The Region<br></br><br></br>
                    <select class="form-select form-select-lg lg-3" aria-label=".form-select-lg example">
                        <option selected disabled>Open this select menu</option>
                        <option value="1">Get</option>
                        <option value="2">data</option>
                        <option value="3">from</option>
                        <option value="3">db</option>
                    </select>



                </div>
            </div>
            <br></br><br></br>
            <div><button type="button" class="btn btn-success" onClick={CandidateSignUp3}>Next</button></div>
        </div>


    </>
}

export default AddressDtl;