import { useHistory } from "react-router-dom/cjs/react-router-dom.min";




function AssemblyDtl() {

   


   
    return<>

        <div> 
            <div className="jumbotron" style={{backgroundColor:'rgb(250, 248, 228)'}} >
                <center><h1>Candidate Sign Up</h1></center>     
                <center><h2>Enter Details</h2></center>  
                <center><h2>3/3</h2></center>     

            </div>  
        </div>
    

  

    <div className="container-fluid text-center"> 

  <div className="row content">
    <div className="col-lg-5 sidenav">

    <div>
    <div><center><big>Assembly Name</big></center></div>
    <input type="text" placeholder="Enter The Assembly name" className="form-control"></input>
    </div>

    <br></br>
    <div>
    <div><center><big>Occupation</big></center></div>
    <input type="text" placeholder="Enter Your Occupation" className="form-control"></input>
    </div>

    <br></br>Select The Region<br></br><br></br>
    <select class="form-select form-select-lg lg-3" aria-label=".form-select-lg example">
        <option selected disabled>Open this select menu</option>
        <option value="1">Get</option>
        <option value="2">data</option>
        <option value="3">from</option>
        <option value="3">db</option>
    </select>


    </div>
    <div className="col-lg-2 text-center"> 

    </div>
    <div className="col-lg-5 sidenav">

    <div>
    <div><center><big>Proof Of Legislation</big></center></div>
    <input type="number" placeholder="Enter The Valid Proof Of Legislation" className="form-control"></input>
    </div>


    <br></br>
    <div>
    <div><center><big>Social Handel</big></center></div>
    <input type="text" placeholder="Enter The Social handel" className="form-control"></input>
    </div>

    <br></br>
    <div className="lg-3">
        Upload Profile Picture <span className="font-css top">*</span>
        <div className="">
            <input type="file" id="file-input" name="ImageStyle"/>
        </div>
    </div>

    </div>
  </div>
  <br></br><br></br>
  <div><button type="button" class="btn btn-success">Submit</button></div>
</div>


    </>
}

export default AssemblyDtl;