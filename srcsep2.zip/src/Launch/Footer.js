
import './Launch.css';

function Footer() {
    return<>
    
    <div className="footer">
        <p>all rights reserved</p>
    </div>
    </>
}

export default Footer;