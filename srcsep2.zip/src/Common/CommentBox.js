


function CommentBox() {
    return<>
    
   
   <div class="jumbotron " className="square bg-primary rounded-6">
    <div class="container">
        <h1>Hello, world!</h1>
        <p>Contents ...</p>
        <p>
            <a class="btn btn-primary btn-lg">Learn more</a>
        </p>
    </div>
   </div>

<br></br>
   <div className="square bg-primary rounded-6 col-lg-4">
        <h1>dfbkjd</h1>
   </div>


   <br></br>

   
   <div class="jumbotron col-lg-4">
    <div class="container">
        <h1>Hello, world!</h1>
        <p>Contents ...</p>
        <p>
            <a class="btn btn-primary btn-lg">Learn more</a>
        </p>
    </div>
   </div>
   
   
    
    
    </>
}

export default CommentBox;