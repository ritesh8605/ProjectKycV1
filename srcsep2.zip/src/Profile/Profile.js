import { useState } from "react";
import HeadNav from "../Common/HeadNav";




function Profile() {

    const [UserData, setUserData] = useState({ UserId: "1001", FirstName: "ritesh", LastName: "Padalwar", Contact: "80079405655", Email: "r@gmail.com", Passsword: "", State: "maharashtra", City: "pandharkawada", StreetName: "pahse2 road", District: "yavatmal", Pincode: "445302" });
    return <>

        <HeadNav></HeadNav>

        <br></br>
        <center>
            <h3>
                Update Your Profile
            </h3>
        </center>

        <br></br>

        <div className="row content">
            <div className="col-lg-2 sidenav">
            </div>
            <div className="col-lg-4 text-center">
                <div>
                    <div><center><big>First Name</big></center></div>
                    <input type="text" value={UserData.FirstName} className="form-control"></input>
                </div>
                <br></br><hr></hr><br></br>
                <div>
                    <div><center><big>Contact</big></center></div>
                    <input type="number" value={UserData.Contact} className="form-control"></input>
                </div>
                <br></br><hr></hr><br></br>
                <div>
                    <div><center><big>State</big></center></div>
                    <input type="text" value={UserData.State}  className="form-control"></input>
                </div>
                <br></br>
                <div>
                    <div><center><big>City</big></center></div>
                    <input type="text" value={UserData.City}  className="form-control"></input>
                </div>
                <br></br>
                <div>
                    <div><center><big>Street Name</big></center></div>
                    <input type="text" value={UserData.StreetName}  className="form-control"></input>
                </div>
                <br></br><hr></hr><br></br>
                <div>
                    <div><center><big>Old Password</big></center></div>
                    <input type="text" placeholder="Enter Old Password" className="form-control"></input>
                </div>
            </div>
            <div className="col-lg-4 text-center">
                <div>
                    <div><center><big>Last Name</big></center></div>
                    <input type="text" value={UserData.LastName} className="form-control"></input>
                </div>
                <br></br><hr></hr><br></br>
                <div>
                    <div><center><big>Email</big></center></div>
                    <input type="text" value={UserData.Email} className="form-control" disabled></input>
                </div>
                <br></br><hr></hr><br></br>
                <div>
                    <div><center><big>District</big></center></div>
                    <input type="text" value={UserData.District} className="form-control"></input>
                </div>

                <br></br>


                <div>
                    <div><center><big>Pincode</big></center></div>
                    <input type="number"value={UserData.Pincode} className="form-control"></input>
                </div>

                <br></br>


                <br></br>Select The Region<br></br><br></br>
                <select class="form-select form-select-lg lg-3" aria-label=".form-select-lg example">
                    <option selected disabled>Open this select menu</option>
                    <option value="1">Get</option>
                    <option value="2">data</option>
                    <option value="3">from</option>
                    <option value="3">db</option>
                </select>



                <br></br><hr></hr><br></br>

                <div>
                <div><center><big>New Password</big></center></div>
                <input type="text" placeholder="Enter The New Password" className="form-control"></input>
            </div>
                <br></br>
            <div>
                <div><center><big>Verify Password</big></center></div>
                <input type="text" placeholder="Verify Password" className="form-control"></input>
            </div>

            </div>

           
            <div className="col-lg-2 sidenav">

            </div>
        </div>


        <br></br><br></br>
        <center>
            <div><button type="button" class="btn btn-success">Sumbit</button></div>
        </center>



    </>
}

export default Profile;