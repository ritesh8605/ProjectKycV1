
function CandidateRow(props) {
    return <tr>
        <td>
          <b>  {props.candidate.firstName}{" "}{props.candidate.lastName}</b>
        </td>
        <td>
           <b> {props.candidate.occupation}</b>
        </td>
        <td>
           <b> {props.candidate.region}</b>
        </td>       
        <td>
           <center>
             <button className='btn btn-danger'
                onClick={() => {
                    props.ViewCandidate(props.candidate.ViewCandidate)
                }}>
                View
            </button>
           </center>
        </td>


    </tr>
}
export default CandidateRow;
